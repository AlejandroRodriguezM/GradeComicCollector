const axios = require('axios');
const cheerio = require('cheerio');

async function fetchImageUrl(url) {
    try {
        // Hacer la solicitud HTTP
        const { data } = await axios.get(url);
        const $ = cheerio.load(data);

        // Obtener el href del enlace que contiene la imagen
        const imageUrl = $('a.cbox-img').attr('href') || '';

        // Mostrar el resultado
        console.log(imageUrl ? `https://comicbookrealm.com${imageUrl}` : 'N/A');
    } catch (error) {
        console.error('Error:', error);
    }
}

// URL de prueba
const url = process.argv[2];

// Llamar a la función para obtener y mostrar la URL de la imagen
fetchImageUrl(url);
