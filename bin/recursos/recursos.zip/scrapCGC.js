const axios = require('axios');
const cheerio = require('cheerio');

async function fetchPageData(url) {
    try {
        // Hacer la solicitud HTTP
        const { data } = await axios.get(url);
        const $ = cheerio.load(data);

        const result = {
            certNumber: '',
            titulo: '',
            numero: '',
            editor: '',
            fechaG: '',
            grade: '',
            referencia: url,
            dibujante: '',
            variante: '',
            key: '',
            guionista: '',
            imageUrl: ''
        };

        // Seleccionar el h2 dentro del li dentro del ul con clase h flag
        const h2Text = $('ul.h.flag li h2').text().trim();
        const numberMatch = h2Text.match(/# (\d+)/);
        if (numberMatch) {
            result.numero = numberMatch[1].trim();
        }

        // Extraer título y editor del div con id forum-crumbs
        $('#forum-crumbs a').each((_, el) => {
            const href = $(el).attr('href');
            const text = $(el).text().trim();
            if (href.includes('series')) {
                result.titulo = text;
            } else if (href.includes('publisher')) {
                result.editor = text;
            }
        });

        // Extraer datos del #slabbed-details
        $('#slabbed-details tr').each((_, el) => {
            const dtText = $(el).find('th').text().replace(':', '').trim();
            const ddText = $(el).find('td').text().trim();

            switch (dtText) {
                case 'Certificate Number':
                    result.certNumber = ddText;
                    break;
                case 'Certified On':
                    result.fechaG = formatDate(ddText);
                    break;
                case 'Publisher':
                    result.editor = ddText;
                    break;
                case 'Certified Grade':
                    result.grade = ddText;
                    break;
                case 'Date of Sale':
                    result.fechaS = formatDate(ddText);
                    break;
                case 'Art Comments':
                    const storiesMatch = ddText.match(/(.*?) stor(?:y|ies)/);
                    const artMatch = ddText.match(/stor(?:y|ies) (.*?) art/);
                    const coverMatch = ddText.match(/art (.*?) cover/);

                    if (storiesMatch) {
                        result.guionista = storiesMatch[1].trim().replace(/ & /g, ' - ');
                    }
                    if (artMatch) {
                        result.dibujante = artMatch[1].trim().replace(/ & /g, ' - ');
                    }
                    if (coverMatch) {
                        result.variante = coverMatch[1].trim().replace(/ & /g, ' - ');
                    }
                    break;
                case 'Key Comments':
                    result.key = ddText;
                    break;
                default:
                    break;
            }
        });

        // Obtener el href del enlace que contiene la imagen
        result.imageUrl = $('a.cbox-img').attr('href') || '';

        return result;
    } catch (error) {
        console.error('Error:', error);
    }
}

function formatDate(dateString) {
    const months = {
        'January': '01',
        'February': '02',
        'March': '03',
        'April': '04',
        'May': '05',
        'June': '06',
        'July': '07',
        'August': '08',
        'September': '09',
        'October': '10',
        'November': '11',
        'December': '12'
    };

    const [month, day, year] = dateString.split(' ');
    const dayFormatted = day.replace(',', '').padStart(2, '0');
    const monthFormatted = months[month];

    return `${year}-${monthFormatted}-${dayFormatted}`;
}

function printData(data) {
    console.log(`Titulo: ${data.titulo || 'N/A'}`);
    console.log(`Certificado: ${data.certNumber || 'N/A'}`);
    console.log(`Numero: ${data.numero || 'N/A'}`);
    console.log(`Editor: ${data.editor || 'N/A'}`);
    console.log(`FechaG: ${data.fechaG || 'N/A'}`);
    console.log(`Grade: ${data.grade || 'N/A'}`);
    console.log(`Referencia: ${data.referencia || 'N/A'}`);
    console.log(`Dibujante: ${data.dibujante || 'N/A'}`);
    console.log(`Variante: ${data.variante || 'N/A'}`);
    console.log(`Guionista: ${data.guionista || 'N/A'}`);
    console.log(`Imagen: ${data.imageUrl ? `https://comicbookrealm.com${data.imageUrl}` : 'N/A'}`);
    console.log(`KeyC: ${data.key || 'N/A'}`);
}

// URL de prueba
const url = 'https://comicbookrealm.com/cgc-analyzer/certificate/id/' + process.argv[2];;

// Llamar a la función para obtener y mostrar los datos
fetchPageData(url).then(printData);
