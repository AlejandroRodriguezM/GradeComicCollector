const axios = require('axios');
const cheerio = require('cheerio');

async function fetchPageData(url) {
    try {
        // Hacer la solicitud HTTP
        const { data } = await axios.get(url);
        const $ = cheerio.load(data);

        const result = {
            certNumber: '',
            titulo: '',
            numero: '',
            editor: '',
            fechaG: '',
            grade: '',
            referencia: url,
            dibujante: '',
            variante: '',
            key: '',
            firma: '',
            guionista: '',
            imageUrl: ''
        };

        // Seleccionar el h2 dentro del li dentro del ul con clase h flag
        const h2Text = $('ul.h.flag li h2').text().trim();
        const numberMatch = h2Text.match(/# (\d+)/);
        if (numberMatch) {
            result.numero = numberMatch[1].trim();
        }

        $('#forum-crumbs a').each((_, el) => {
            const href = $(el).attr('href');
            const text = $(el).text().trim();
            if (href.includes('series')) {
                result.titulo = text;
            } else if (href.includes('cgc-analyzer/publisher')) {
                result.editor = text;
            }
        });

        // Extraer datos del #slabbed-details
        $('#slabbed-details tr').each((_, el) => {
            const dtText = $(el).find('th').text().replace(':', '').trim();
            const ddText = $(el).find('td').text().trim();

            switch (dtText) {
                case 'Certificate Number':
                    result.certNumber = ddText;
                    break;
                case 'Certified On':
                    result.fechaG = formatDate(ddText);
                    break;
                case 'Certified Grade':
                    result.grade = ddText;
                    break;
                case 'Signed By':
                    result.firma = ddText;
                    break;
                case 'Date of Sale':
                    result.fechaS = formatDate(ddText);
                    break;
                case 'Art Comments':
                    // Extraer y acumular datos de Art Comments
                    const artStoriesMatch = ddText.match(/(.*?) stor(?:y|ies)/);
                    const artArtMatch = ddText.match(/stor(?:y|ies) (.*?) art/);
                    const artCoverMatch = ddText.match(/art (.*?) cover/);

                    if (artStoriesMatch) {
                        result.guionista += (result.guionista ? ' - ' : '') + artStoriesMatch[1].trim().replace(/ & /g, ' - ');
                    }
                    if (artArtMatch) {
                        result.dibujante += (result.dibujante ? ' - ' : '') + artArtMatch[1].trim().replace(/ & /g, ' - ');
                    }
                    if (artCoverMatch) {
                        result.variante += (result.variante ? ' - ' : '') + artCoverMatch[1].trim().replace(/ & /g, ' - ');
                    }
                    break;
                case 'Key Comments':
                    // Extraer y acumular datos de Key Comments
                    const keyStoriesMatch = ddText.match(/(.*?) stor(?:y|ies)/);
                    const keyArtMatch = ddText.match(/stor(?:y|ies) (.*?) art/);
                    const keyCoverMatch = ddText.match(/art (.*?) cover/);

                    if (keyStoriesMatch) {
                        result.guionista += (result.guionista ? ' - ' : '') + keyStoriesMatch[1].trim().replace(/ & /g, ' - ');
                    }
                    if (keyArtMatch) {
                        result.dibujante += (result.dibujante ? ' - ' : '') + keyArtMatch[1].trim().replace(/ & /g, ' - ');
                    }
                    if (keyCoverMatch) {
                        result.variante += (result.variante ? ' - ' : '') + keyCoverMatch[1].trim().replace(/ & /g, ' - ');
                    }

                    result.key = ddText;
                    break;
                default:
                    break;
            }
        });

        result.imageUrl = $('a.cbox-img').attr('href') || '';

        return result;
    } catch (error) {
        console.error('Error fetching page data:', error);
        return null;
    }
}

function formatDate(dateString) {
    const months = {
        'January': '01',
        'February': '02',
        'March': '03',
        'April': '04',
        'May': '05',
        'June': '06',
        'July': '07',
        'August': '08',
        'September': '09',
        'October': '10',
        'November': '11',
        'December': '12'
    };

    const [month, day, year] = dateString.split(' ');
    const dayFormatted = day.replace(',', '').padStart(2, '0');
    const monthFormatted = months[month];

    return `${year}-${monthFormatted}-${dayFormatted}`;
}

function printData(data) {
    console.log(`Titulo: ${data.titulo}`);
    console.log(`Certificado: ${data.certNumber}`);
    console.log(`Numero: ${data.numero}`);
    console.log(`Editor: ${data.editor}`);
    console.log(`FechaG: ${data.fechaG}`);
    console.log(`Grade: ${data.grade}`);
    console.log(`Firma: ${data.firma}`);
    console.log(`Referencia: ${data.referencia}`);
    console.log(`Dibujante: ${data.dibujante}`);
    console.log(`Variante: ${data.variante}`);
    console.log(`Guionista: ${data.guionista}`);
    console.log(`Imagen: https://comicbookrealm.com${data.imageUrl}`);
    console.log(`KeyC: ${data.key}`);
}

// URL de prueba
const url = process.argv[2];

// Llamar a la función para obtener y mostrar los datos
fetchPageData(url).then(printData);
